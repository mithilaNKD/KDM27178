﻿using System;

namespace SummationConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Check If A Given Number Is Even Or Odd");

            int Num;

            Console.Write("Enter A Number: ");
            Num = int.Parse (Console.ReadLine());

            if (Num % 2 == 0)
            {
                Console.WriteLine("This Number Is An Even Number");
            }

            else
            {
                Console.WriteLine("This Number Is An Odd Number");
            }

            Console.ReadLine(); 

        }
    }
}