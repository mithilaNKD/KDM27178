﻿using System;

namespace SummationConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Check If A Given Numbers Is Even Or Odd");

            int[] Nums = new int[10];
            int i;

            for (i = 0; i < 10; i++) 
            {
                Console.Write("Enter A Number: ");
                Nums[i] = int.Parse(Console.ReadLine());
            }

            for (i = 0;i < 10; i++) 
            {
                if (Nums[i] % 2 == 0)
                {
                    Console.WriteLine("This Number Is An Even Number");
                }

                else
                {
                    Console.WriteLine("This Number Is An Odd Number");
                }

            }

          Console.ReadLine();

        }
    }
}