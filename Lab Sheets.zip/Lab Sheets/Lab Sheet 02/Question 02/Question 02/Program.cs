﻿using System;

namespace CalculationSumConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Summation of two values ");
            int Num1, Num2, Sum, Sub, Multi, Dev;

            Console.Write("Enter First Value: ");
            Num1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Second Value: ");
            Num2 = Convert.ToInt32(Console.ReadLine());

            {
                //Summation
                Sum = Num1 + Num2;
                Console.WriteLine("The Summation Is: " + Sum);
            }

            {
                //subtraction
                Sub = Num1 - Num2;
                Console.WriteLine("The subtraction Is: " + Sub);
            }

            {
                //multiplication
                Multi = Num1 * Num2;
                Console.WriteLine("The Multipication Is: " + Multi);
            }

            {
                //division
                Dev = Num1 / Num2;
                Console.WriteLine("The Devision is: " + Dev);
            }

            Console.ReadKey();

        }
    }
}
