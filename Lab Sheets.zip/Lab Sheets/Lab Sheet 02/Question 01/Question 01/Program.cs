﻿using System;

namespace CalculationSumConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Summation of two values ");
            int Num1, Num2, Sum;

            Console.Write("Enter First Value: ");
            Num1 =Convert.ToInt32 (Console.ReadLine());

            Console.Write("Enter Second Value: ");
            Num2 = Convert.ToInt32(Console.ReadLine());

            {
                Sum = Num1 + Num2;
                Console.WriteLine("The Sum Is: " + Sum);
            }

            Console.ReadKey();

        }
    }
}
