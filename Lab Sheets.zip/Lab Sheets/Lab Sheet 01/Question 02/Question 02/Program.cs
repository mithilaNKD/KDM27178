﻿using System;

namespace CalculateAreaConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Calculate Area Of A Circle ");

            double Radius, Area;
            Console.Write("Enter The Radius Of The Circle: ");
            Radius = Convert.ToDouble (Console.ReadLine());

            //Calculation
            
            Area = Math.PI * Radius *Radius;

            //OutPut
            
            Console.WriteLine("Calculated Radius Is  {0}",Radius);
            Console.WriteLine("Area Of The Circle Is {0}", Area);

            Console.WriteLine("Press any Key to Exit");
            Console.ReadKey();
        }
    }
}
