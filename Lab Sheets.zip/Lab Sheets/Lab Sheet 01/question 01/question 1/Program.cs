﻿using System;

namespace question01ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Your Name And Batch Here");

            //Read

            Console.Write("Enter Your Name: ");
            string Name = Console.ReadLine();

            Console.Write("Enter Your Batch: ");
            string Batch = Console.ReadLine();

            //Print

            Console.WriteLine($"Your Name Is: {Name}");
            Console.WriteLine($"Your Batch Is: {Batch}");
            
            
            Console.ReadKey();
        }
    }
}
