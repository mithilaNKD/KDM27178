﻿using System;

namespace SalaryCalculatorConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Calculate Salary after The Tax");

            int Salary, TaxRate, AfterTax;

            Console.Write("Enter The Salary Rate: ");
            String SalaryInput = Console.ReadLine();

            Console.Write("Enter The Tax Rate (in percentage) : ");
            String TaxInput = Console.ReadLine();

            AfterTax = Salary - (Salary * (TaxRate / 100));

            Console.WriteLine($"Salary after tax deduction:"+AfterTax);



            Console.ReadKey();
        }


        
    }
}
