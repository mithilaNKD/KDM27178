﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter an integer: ");
            int num = int.Parse(Console.ReadLine());

            int sum = 0, odds = 0;

            for (int temp = num; temp != 0; temp /= 10)
            {
                int digit = temp % 10;
                if (digit % 2 != 0)
                    sum += digit;
            }
            Console.Write("sum of odds: " + sum);
            Console.ReadLine();
        }

    }
}
