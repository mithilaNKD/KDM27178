﻿using System;

namespace SummationConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Check If A Given Number Is Even Or Odd");


            Console.ReadLine();

        }
    }
}
