﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class SumOfDigits
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Find The Sum Of The Digits Of A Given Number");

        Console.Write("Enter a number: ");
        int number = int.Parse(Console.ReadLine());

        int sum = 0;

        for (int temp = number; temp != 0; temp /= 10)
        {
            int digit = temp % 10;
            sum += digit;
        }

        Console.WriteLine("Sum of digits: " + sum);

        Console.ReadLine();
    }
}

