﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Counting counts the number of vowels in a given string ");

            var vowelsArray = new[] { 'a', 'e', 'i', 'o', 'u' };

            Console.Write("Enter The String: ");
            var stringInput = Console.ReadLine().ToLower();

            var no_ofvowelcount = stringInput.Count(x => vowelsArray.Contains(x));

            Console.WriteLine("Your Total Number Of vowels Is {0}",no_ofvowelcount);

            Console.ReadLine();

        }
    }
}
